# ElevateeX Admin Portal (Standalone)

This is a **standalone admin portal** extracted from the main ElevateeX project. It's designed to run independently and connect to your custom backend API.

## 🚀 Quick Start

1. **Install dependencies:**
   ```bash
   npm install
   ```

2. **Configure your backend API:**
   - Open `lib/api.ts`
   - Change `API_BASE_URL` to your backend URL
   - Or set environment variable: `NEXT_PUBLIC_API_URL=http://your-backend-url`

3. **Run the dev server:**
   ```bash
   npm run dev
   ```
   Admin portal will run on: **http://localhost:5000**

4. **Login:**
   - Go to http://localhost:5000/admin/login
   - Default password: `admin123`
   - Change password in `app/admin/login/page.tsx`

## 📁 Project Structure

```
ElevateeX-Admin/
├── app/
│   └── admin/
│       ├── layout.tsx           # Admin sidebar & navigation
│       ├── page.tsx             # Dashboard
│       ├── login/page.tsx       # Login page
│       ├── courses/
│       │   ├── page.tsx         # Courses list
│       │   ├── new/page.tsx     # Create course
│       │   └── [id]/page.tsx    # Edit course
│       ├── customers/page.tsx   # Customers & enrollments
│       └── revenue/page.tsx     # Revenue analytics
├── components/
│   └── ThemeProvider.tsx        # Theme provider (light theme)
├── lib/
│   ├── types.ts                 # TypeScript types
│   └── api.ts                   # API configuration
└── package.json
```

## 🔌 Backend API Requirements

Your backend should implement these endpoints:

### Courses
- `GET /api/courses` - Get all courses
- `POST /api/courses` - Create course
- `GET /api/courses/:id` - Get single course
- `PUT /api/courses/:id` - Update course
- `DELETE /api/courses/:id` - Delete course

### Customers
- `GET /api/customers` - Get all customers
- `GET /api/customers/:id` - Get single customer
- `DELETE /api/customers/:id` - Delete customer

### Enrollments
- `POST /api/enroll` - Create enrollment

### Export (Optional)
- `GET /api/export/customers` - Export customers Excel
- `GET /api/export/revenue` - Export revenue Excel

## 📊 Data Types

All TypeScript types are defined in `lib/types.ts`:
- `Course` - Course with parts and content
- `Customer` - Customer with enrollments
- `Enrollment` - Single enrollment record
- `CoursePart` - Course part/module
- `ContentItem` - Content (video, PDF, etc.)

## 🎨 Customization

### Change Port
Edit `package.json`:
```json
"dev": "next dev -p YOUR_PORT"
```

### Change Admin Password
Edit `app/admin/login/page.tsx`:
```typescript
const ADMIN_PASSWORD = 'your-new-password'
```

### Change Theme/Colors
Edit `app/globals.css` - CSS variables under `[data-theme="light"]`

## 🔐 Security Notes

⚠️ **IMPORTANT:**
1. Change the default admin password before deployment
2. Implement proper authentication (JWT, sessions, etc.)
3. Add CORS configuration on your backend
4. Use HTTPS in production
5. Validate all API inputs on backend

## 📦 Production Build

```bash
npm run build
npm run start
```

## 🌐 Deployment

This is a standard Next.js app. Deploy to:
- **Vercel**: `vercel --prod`
- **Docker**: Create Dockerfile with Node.js
- **VPS**: Use PM2 or systemd

## 🔗 Connecting to Backend

1. Create your backend with the required API endpoints
2. Set `NEXT_PUBLIC_API_URL` environment variable
3. Ensure CORS is configured on backend:
   ```javascript
   // Example Express.js CORS
   app.use(cors({
     origin: 'http://localhost:5000',
     credentials: true
   }))
   ```

## 📝 License

This admin portal is part of the ElevateeX project.

---

**Need Help?** Check the original ElevateeX project documentation or create an issue.
