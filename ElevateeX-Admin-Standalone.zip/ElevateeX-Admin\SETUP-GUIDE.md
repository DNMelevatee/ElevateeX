# ElevateeX Admin Portal - Complete Setup Guide

## 📋 Step-by-Step Setup (Hindi + English)

### Step 1: Extract & Open Project

1. **Is folder ko apne Desktop/Downloads par copy karein**
2. **VS Code mein open karein:**
   - VS Code kholein
   - File → Open Folder
   - `ElevateeX-Admin` folder select karein

### Step 2: Install Dependencies

Terminal mein likho:
```bash
npm install
```

Wait karo jab tak sab packages install na ho jaayein (30-60 seconds)

### Step 3: Configure Backend URL

**Option A: Use Main ElevateeX Project (Recommended for testing)**

Agar main ElevateeX project port 4000 par chal raha hai, to kuch change karne ki zarurat nahi hai.

**Option B: Connect to Your Own Backend**

1. `.env.example` ko copy karke `.env.local` banao
2. `.env.local` file mein backend URL change karo:
   ```
   NEXT_PUBLIC_API_URL=http://your-backend-url:port
   ```

### Step 4: Run Admin Portal

```bash
npm run dev
```

Admin portal **http://localhost:5000** par khul jaayega

### Step 5: Login

1. Browser mein jaao: **http://localhost:5000**
2. Auto-redirect hoga `/admin/login` par
3. Password daalo: **admin123**
4. Click "Sign In"

---

## 🔌 Backend Connection Guide

### Scenario 1: Testing with Main ElevateeX Project

```bash
# Terminal 1 - Main Project (port 4000)
cd path/to/elevateeX
npm run dev

# Terminal 2 - Admin Portal (port 5000)
cd path/to/ElevateeX-Admin
npm run dev
```

Admin portal automatically connect ho jaayega main project se.

### Scenario 2: Connect to Custom Backend

Aapka backend in endpoints ko implement karna padega:

#### Required API Endpoints:

**Courses Management:**
```
GET    /api/courses          → Get all courses
POST   /api/courses          → Create new course
GET    /api/courses/:id      → Get single course
PUT    /api/courses/:id      → Update course
DELETE /api/courses/:id      → Delete course
```

**Customers Management:**
```
GET    /api/customers        → Get all customers
GET    /api/customers/:id    → Get single customer
DELETE /api/customers/:id    → Delete customer
```

**Enrollments:**
```
POST   /api/enroll           → Create enrollment
```

**Excel Export (Optional):**
```
GET    /api/export/customers → Download customers Excel
GET    /api/export/revenue   → Download revenue Excel
```

#### CORS Configuration (Important!)

Aapke backend mein CORS enable karna padega:

**Express.js Example:**
```javascript
const cors = require('cors');

app.use(cors({
  origin: 'http://localhost:5000',  // Admin portal URL
  credentials: true
}));
```

**Node.js + Next.js API Routes:**
```javascript
// Add headers to your API responses
res.setHeader('Access-Control-Allow-Origin', 'http://localhost:5000');
res.setHeader('Access-Control-Allow-Methods', 'GET,POST,PUT,DELETE');
res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
```

---

## 🎨 Customization

### Change Admin Password

File: `app/admin/login/page.tsx`
```typescript
const ADMIN_PASSWORD = 'your-new-secure-password'
```

### Change Port

File: `package.json`
```json
"scripts": {
  "dev": "next dev -p 6000",    // Change 5000 to any port
  "start": "next start -p 6000"
}
```

### Add Authentication (Recommended for Production)

Replace localStorage authentication with:
- JWT tokens
- Session-based auth
- OAuth/Auth0
- NextAuth.js

---

## 📊 Features Overview

### Dashboard (/)
- Total revenue stats
- Customer count
- Active courses
- Recent enrollments
- Quick course overview

### Courses (/admin/courses)
- List all courses
- Create new course
- Edit course (content builder)
- Publish/unpublish
- Delete course
- **Content Types:** Video, PDF, PPT, DOCX, Images, Links, Text

### Customers (/admin/customers)
- View all customers
- See enrollments per customer
- Track revenue per customer
- Export to Excel
- Delete customers

### Revenue (/admin/revenue)
- Total revenue overview
- Revenue by duration (1mo, 3mo, 6mo)
- Revenue by course
- Monthly revenue chart
- Transaction history
- Export to Excel

---

## 🚀 Production Deployment

### Build for Production

```bash
npm run build
npm run start
```

### Deploy to Vercel

```bash
npm i -g vercel
vercel --prod
```

**Add Environment Variable on Vercel:**
- Go to Project Settings → Environment Variables
- Add: `NEXT_PUBLIC_API_URL` = `https://your-backend.com`

### Deploy to VPS/Server

```bash
# Install PM2
npm i -g pm2

# Build
npm run build

# Start with PM2
pm2 start npm --name "elevateeX-admin" -- start

# Save PM2 process
pm2 save
pm2 startup
```

---

## 🔐 Security Checklist

Before going live:

- [ ] Change admin password
- [ ] Implement proper authentication (JWT/sessions)
- [ ] Add HTTPS (SSL certificate)
- [ ] Enable CORS only for your domain
- [ ] Add rate limiting on backend
- [ ] Validate all inputs on backend
- [ ] Use environment variables for secrets
- [ ] Add API authentication (API keys/tokens)
- [ ] Enable backend request logging
- [ ] Add CSP (Content Security Policy) headers

---

## 🐛 Common Issues & Solutions

### Issue: "Cannot connect to backend"
**Solution:**
- Check if backend is running
- Verify `NEXT_PUBLIC_API_URL` in `.env.local`
- Check CORS configuration on backend
- Open browser console for exact error

### Issue: "Login not working"
**Solution:**
- Clear browser localStorage
- Check password in `app/admin/login/page.tsx`
- Try incognito/private window

### Issue: "Port already in use"
**Solution:**
```bash
# Windows
netstat -ano | findstr :5000
taskkill /PID <PID> /F

# Linux/Mac
lsof -ti:5000 | xargs kill -9
```

### Issue: "Excel export not working"
**Solution:**
- Ensure `xlsx` package is installed: `npm install xlsx`
- Check backend `/api/export/*` endpoints
- Verify CORS allows file downloads

---

## 📞 Support

Need help?
1. Check the main README.md
2. Review browser console for errors
3. Check backend logs
4. Verify API endpoints with Postman/Thunder Client

---

**Happy Coding! 🚀**

*ElevateeX Admin Portal - Manage your courses with ease*
