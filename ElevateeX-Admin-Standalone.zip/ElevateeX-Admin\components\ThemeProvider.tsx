'use client'
import { createContext, useContext } from 'react'

// Single light theme
type Theme = 'light'

const ThemeCtx = createContext<{ theme: Theme; toggle: () => void }>({
  theme: 'light',
  toggle: () => {},
})

export const useTheme = () => useContext(ThemeCtx)

export function ThemeToggle() {
  return null
}

export function ThemeProvider({ children }: { children: React.ReactNode }) {
  return (
    <ThemeCtx.Provider value={{ theme: 'light', toggle: () => {} }}>
      <div data-theme="light">{children}</div>
    </ThemeCtx.Provider>
  )
}
